// pages/question/question.js
const app = getApp()
import util from '../Utils/util';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array:[
      {
        q_body:null,//题目
        //类型 默认为单选
        q_type:2,
        radioitems:[
          { value: 0, name:"问答"},
          { value: 1, name:"单选"},
          { value: 2, name:"多选",checked:"true"}
        ],
        //选项
        options: [
          { c_body:null}
        ]
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
   //增加题目
  insert: function () {
    var temp= [
      {
        q_body:null,
        q_type:1,
        radioitems: [
          { value: 0, name: "问答" },
          { value: 1, name: "单选" },
          { value: 2, name: "多选" , checked: "true" }
        ],
        options: [
          { c_body:null}
        ]
      }
    ]
    this.setData({
      'array': this.data.array.concat(temp),
    })
  },
  //增加选项
  insert2: function (e) {
    var newoptions = { c_body:null}
    var index = e.currentTarget.dataset.arrayindex
    var temp = this.data.array;
    temp[index].options.push(newoptions);
    this.setData({
      array:temp
    })
  },
  //删除题目
  delete:function()
  {
    var temp = this.data.array;
    temp.pop();
    this.setData({
      array: temp,
    })
  },
  //删除选项
  delete2: function (e) 
  {
    var temp = this.data.array
    var index = e.currentTarget.dataset.arrayindex
    temp[index].options.pop();
    this.setData({
      array: temp
    })
  },
  //选择题目类型
  radioChange(e) {
    //console.log(e)
   // console.log(e.detail.value)
    var temp = this.data.array
    var arrayindex = e.currentTarget.dataset.arrayindex
    var len = this.data.array[arrayindex].raidoitems

    for (let i = 0; i < len; ++i) {
      temp[arrayindex].radioitems[i].checked = temp[arrayindex].radioitems[i].value === e.detail.value
    }
    temp[arrayindex].q_type = e.detail.value
    this.setData({
      array:temp
    })
  },

  sleep:function(numberMillis) {
    var now = new Date();
    var exitTime = now.getTime() + numberMillis;
    while(true) {
      now = new Date();
      if (now.getTime() > exitTime)
        return;
    }
  },


  //输入问题题目
  nameinput:function(e)
  {
    var index = e.currentTarget.dataset.arrayindex
    var temp = this.data.array
    temp[index].q_body =e.detail.value
    this.setData({
      array:temp
    })
  },
  //输入选项
  optioninput:function(e)
  {
    //console.log(e)
    var arrayindex = e.currentTarget.dataset.arrayindex
    var optionsindex = e.currentTarget.dataset.optionsindex
    var temp = this.data.array
    temp[arrayindex].options[optionsindex].c_body = e.detail.value
    this.setData({
      array:temp
    })
  },
  //完成提交
  submit:function()
  {
    var temp = this.data.array
    let token = app.globalData.userInfo
    var flag = 0
    var id = wx.getStorageSync('current_id')//从本地缓存取id
    for(let i=0;i<temp.length;i++)
    {

      if (temp[i].q_body == null)//题目为空
      {
        flag = 1
        wx.showToast({
          title: '题目不能为空',
          icon: 'none',
          duration: 2000
        }) 
      }
      else
      {
        for (let j = 0; j < temp[i].options.length;j++)
        {

          if (temp[i].options[j].c_body==null)
          {
            if(temp[i].q_type==0){
              var temp = this.data.array
             temp[i].options[j].c_body = "0"
             this.setData({
               array:temp
             })             
            }
            else{
            flag = 1
            wx.showToast({
              title: '选项不能为空',
              icon: 'none',
              duration: 2000
            }) 
          }
          }
        }
      }
    }
    if(flag==0)//都不为空
    {
      var timer
      var time1 = 1;
      for(let k=0;k<temp.length;k++)//发送问题创建请求
      { 
        
        //要延时执行的代码
        console.log("time:"+time1);
        time1++;
       
        console.log(temp[k].q_body)
        console.log(temp[k].q_type)
        console.log(id)
        console.log(temp[k].options)
        this.sleep(150);
        wx.request({
          url: 'http://jijuan.gleeze.com/api/question/',
          method: "POST",
          

          data: {
            q_body: temp[k].q_body,
            q_type: temp[k].q_type,
            survey: id,
            question: temp[k].options
          },
          header: {
            "Authorization": ('Token ' + token),
            "Content-Type": "application/json"
          },
          success: function (res) {
            wx.showModal({
              title: '问卷创建完成',      
              content: '问卷id:'+id+'\n是否复制到粘贴板',
              cancelText:'复制',
              success: function(res){        
                if (res.confirm) {          
                  console.log('确定')        
                } else if (res.cancel){          
                  wx.setClipboardData({
                    data: toString(id),
                    success:function(res)
                    {
                      wx.getClipboardData({
                        success: (option) =>{}
                      })
                    }
                  })     
                }      
              },
              complete:function(res)
              {
                setTimeout(function () {
                  //要延时执行的代码
                  wx.switchTab({
                    url: '/pages/index/index',
                  })
                 }, 1500);
                
              }
            })
          },
          fail:function(res)
          {
            wx.showToast({
              title: '创建失败，请重新检查',
              icon: 'none',
              duration: 2000
            }) 
          }
        })
      }
        
    }
    
  }

})

