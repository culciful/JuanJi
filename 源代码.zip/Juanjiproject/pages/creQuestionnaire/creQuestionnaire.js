// pages/creQuestionnaire/creQuestionnaire.js
const app = getApp()
import util from '../Utils/util';
Page({
  data:{
      s_title:null,//名字
      synopsis:null,//简介
      s_stop_time:'',
      date:'',//日期
      time:'',//时间
  },

  /**
   * 页面的初始数据
   */

  /**
   * 生命周期函数--监听页面加s载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 返回上一级
  goback(){
    this.data.s_title = null;
    wx.navigateBack({
    })
  },
  //获取输入的问卷名字
  isinput:function(e){
    this.data.s_title = e.detail.value
  },
  //获取问卷简介
  isinput2: function (e) {
    this.data.synopsis = e.detail.value
  },
  //日期
  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  //时间
  bindTimeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time: e.detail.value
    })
  },
  //跳到创建题目界面
  gotoQuestion(){
    var that = this
    var input = that.data.s_title 
    let token = app.globalData.userInfo
    var date = this.data.date
    var time = this.data.date
    var stoptime = this.data.date +"T00:"+ this.data.time+"+08:00"//截止日期,/
    console.log(stoptime)
    if(!input||!date||!time)
    {
      wx.showToast({
        title: '问卷标题与截止时间不能为空',
        icon: 'none',
        duration: 2000
      }) 
    }
    else{
      wx.request({
        url: 'http://jijuan.gleeze.com/api/survey_list/',
        method: "POST",
        data: util.json2Form({
          s_title: this.data.s_title,//名字
          s_intro: this.data.synopsis,//简介
          s_stop_time: stoptime,//截止日期
          s_owner:1
        }),      
        header: {
            "Authorization": ('Token ' + token),
            "Content-Type": "application/x-www-form-urlencoded"
          },
          success:function(res)
          {
            console.log(res.data)
            console.log("request ok")
            wx.setStorageSync('current_id', res.data.id)//id存入本地缓存
            wx.navigateTo({
              url: '/pages/question/question',
            })

          }
      })
    }
  },
})