const app = getApp()
const token = app.globalData.userInfo
Page({

  /**
   * 页面的初始数据
   */
/*  data: {
    person:{
      name:"张三",
      time:"2020-6-9",
      question:"爱好调查"
    },
    
    que_list:[
      {
        id:0,
        name:"what do you like?",
        type:"checkbox",
        options:[
          {
            id:0,
            op:"banana"
          },
          {
            id:0,
            op:"apple"
          }
        ]
      },
      {
        id:1,
        name:"what do you hate?",
        type:"radio",
        options:[
          {
            id:0,
            op:"orange"
          },
          {
            id:0,
            op:"lemen"
          }
        ]
      },
      {
        id:2,
        name:"what do you want?",
        type:"statement"
      }
    ]
  },*/
  data:{},
  deleteBtnClick: function () {
    var that=this
    let token = app.globalData.userInfo
    wx.showModal({
      title: '删除问卷',
      content: '确定要删除该问卷？',
      success: function (res) {
         if (res.cancel) {
            //点击取消,默认隐藏弹框
         } else {
            //点击确定
            wx:wx.request({
              url: ('http://jijuan.gleeze.com/api/survey/'+that.data.id),
              header: {
                'Authorization': ('Token '+token),
                "Content-Type": "application/x-www-form-urlencoded"
              },
              method: "DELETE",
              success: (res) => {
                wx.switchTab({
                  url: '../index/index'
                })
              },
            })
         }
            
         }
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this 
    var headURL = 'http://jijuan.gleeze.com/api/survey/'

    wx.request({
      url: (headURL+options.id+'/?format=json'), //这里填写你的接口路径
      header: { 
       'Content-Type': 'application/json'
      },

      success: function(res) {
      //这里就是请求成功后，进行一些函数操作
      console.log(res.data)
      _this.setData({
        id: options.id
      })
      _this.setData({
        intro: res.data.s_intro
      })
      _this.setData({
        que_list: res.data.survey
      })
      _this.setData({
        question: res.data.s_title
      })
      _this.setData({
        time: res.data.s_stop_time
      })
      _this.setData({
        name: res.data.s_owner
      })
      var d = new Date()
      var time = _this.data.time
      var flag = 0
      var days =new Date(time.substring(0,10)+' '+time.substring(11,19))
      var num = days.getTime() - d.getTime()
      var len = _this.data.que_list.length 

      if(num>0)flag=1
      _this.setData({
          flag: flag
      })
      if(flag==1){
        num = parseInt(num/1000/60/60/24)
        _this.setData({
          day: num
      })  
      }

      var i=0 
      for(i=0;i<len;i++){ 
        _this.setData({ 
          ['que_list['+i+'].num']:i+1 
      }) 
      } 
      
      }
     })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})