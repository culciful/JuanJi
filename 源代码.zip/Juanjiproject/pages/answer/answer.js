// pages/answer/answer.js
const app = getApp()
const token = app.globalData.userInfo
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this 
    var headURL = 'http://jijuan.gleeze.com/api/question/'
    let token = app.globalData.userInfo
    console.log(options)
    wx.request({
      url: (headURL+options.id+'/?format=json'), //这里填写你的接口路径
      header: { 
        'Authorization': ('Token '+token),
       'Content-Type': 'application/json'
      },

      success: function(res) {
      //这里就是请求成功后，进行一些函数操作
      console.log(res.data)
      _this.setData({
        answer: res.data.answers
      }) 
      _this.setData({
        type: options.type
      }) 
      _this.setData({
        body: options.q_body
      }) 
      _this.setData({
        id: options.id
      }) 
      _this.setData({
        num: res.data.num
      }) 

      var answer = _this.data.answer
      var type = _this.data.type
      var len = answer.length
      var flag = 1
      if(len==0) flag=0
      _this.setData({
        flag: flag
      }) 
      var i = 0
      var answercontent = []
      var answernum = []
      if(flag==1){
      if(type == 0){
        answercontent[i]=(answer[i].ta_body)
      }
      else{
        answercontent[i]=(answer[i].c_body)
      }
        answernum[i]=1
        _this.setData({
          ['answercontent['+i+'].c'] : answercontent[i]
        }) 
        _this.setData({
          ['answercontent['+i+'].n'] : answernum[i]
        }) 
        var body
        var inde = 1
        for(i=1;i<len;i++){
          if(type==0)
          var body = answer[i].ta_body
          else var body = answer[i].c_body
          if(answercontent.includes(body)){
            var index=answercontent.indexOf(body)
            answernum[index] = answernum[index]+1
            _this.setData({
              ['answercontent['+index+'].n'] : answernum[index]
            })             
          }
          else{
            answercontent[inde]=(body)
            answernum[inde]=1
            _this.setData({
              ['answercontent['+inde+'].c'] : answercontent[inde]
            }) 
            _this.setData({
              ['answercontent['+inde+'].n'] : answernum[inde]
            }) 
            inde = inde+1
          }          
        }    
      }
      }
      })

},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})