// pages/answer/answer.js
import util from '../Utils/util';
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    answer:[],
  },
  // data:{},

  
  
  //多选
  checkboxChange: function (e) {
    var id = e.target.dataset.id

    var temp = 
    {
      question_id: id,
      answer_choices:e.detail.value
    }
    var {answer} = this.data;
    // remove(answer,id);
    for(let i =0;i<answer.length;i++){
      if(answer[i].question_id==id){
        answer.splice(i,1);
      }
    }
    console.log(temp)
    answer.push(temp);
    this.setData({
      answer:answer
    })
  },
  //刪除多余数组
  /*
  remove: function(array,val){
    for(let i =0;i<array.length;i++){
      if(array[i].question_id==val){
        array.splice(i,1);
      }
    }
    this.setData({
      answer:array
    })
  },*/
  //单选
  radioChange: function (e) {
    var id = e.target.dataset.id
    var temp = 
    {
      question_id: e.target.dataset.id,
      answer_choices:[
        e.detail.value
      ]
    }
    var {answer} = this.data;
    for(let i =0;i<answer.length;i++){
      if(answer[i].question_id==id){
        answer.splice(i,1);
      }
    }
    answer.push(temp);
    this.setData({
      answer:answer
    })
  },
  //问答
  answerInput(e) {
    var id = e.target.dataset.id
    var temp = 
    {
      question_id: e.target.dataset.id,
      answer_text:e.detail.value
    }
    var {answer} = this.data;
    for(let i =0;i<answer.length;i++){
      if(answer[i].question_id==id){
        answer.splice(i,1);
      }
    }
    answer.push(temp);
    this.setData({
      answer:answer
    })
  },
  //提交
  submit:function(){
    var {answer} = this.data
    var {que_list} = this.data
    if(answer.length<que_list.length){
      wx.showToast({
        title: '回答不能为空',
        icon: 'none',
        duration: 2000
      }) 
    }
    else{
      wx.request({
        url:'http://jijuan.gleeze.com/api/survey_result/'+this.data.id+'/',
        method:"POST",
        data: {
          answers:answer
        },
        header: {
          "Content-Type": "application/json"
        },
        success: (res)=>{
          wx.showToast({
            title: '成功',
            icon: 'success',
            duration: 3000
          })
          wx.navigateBack({
          })
        },
        fail: (res)=>{
          wx.showToast({
            title: '请求出错',
            icon: 'none',
            duration: 3000
        });
    }
  })
}
  },
  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    
    var _this = this
    _this.setData({
      id : options.id
    })
    var headURL = 'http://jijuan.gleeze.com/api/survey/'

    wx.request({
      url: (headURL + options.id + '/?format=json'), //这里填写你的接口路径
      header: {
        'Content-Type': 'application/json'
      },

      success: function (res) {
        //这里就是请求成功后，进行一些函数操作
        console.log(res.data)
        _this.setData({
          que_list: res.data.survey
        })
        _this.setData({
          question: res.data.s_title
        })
        _this.setData({
          time: res.data.s_stop_time
        })
        _this.setData({
          name: res.data.s_owner
        })
        _this.setData({
          intro: res.data.s_intro
        })
        var len = _this.data.que_list.length 
      var d = new Date()
      var time = _this.data.time
      var flag = 0
      var days =new Date(time.substring(0,10)+' '+time.substring(11,19))
      var num = days.getTime() - d.getTime()
      if(num>0)flag=1
      _this.setData({
          flag: flag
      })
      if(flag==1){
        num = parseInt(num/1000/60/60/24)
        _this.setData({
          day: num
      })  
      }
      var i=0 
      for(i=0;i<len;i++){ 
        _this.setData({ 
          ['que_list['+i+'].num']:i+1 
      }) 
      }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})