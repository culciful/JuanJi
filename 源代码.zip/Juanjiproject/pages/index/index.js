//Page Object
const app = getApp()
const token = app.globalData.userInfo
Page({
  data: {
    
  },
  //options(Object)
  onLoad: function(options){
    
  },
  onReady: function(){
    
  },
  onShow: function(){
    var _this = this 
    let token = app.globalData.userInfo

    wx.request({
      url: 'http://jijuan.gleeze.com/api/survey_list/', //这里填写你的接口路径
      header: {
       'Authorization': ('Token '+token),
       'Content-Type': 'application/json' 
      },

      success: function(res) {
      //这里就是请求成功后，进行一些函数操作
      console.log(res.data)
      _this.setData({
        list: res.data.surveys
      })
      var list = _this.data.list
      var len = list.length
      console.log(len)
      var i = 0
      var d = new Date()
      for(i=0;i<len;i++){
        var flag = 0
        var days =new Date(list[i].s_stop_time.substring(0,10)+' '+list[i].s_stop_time.substring(11,19))
        var num = days.getTime() - d.getTime()
        if(num>0)flag=1

        _this.setData({
          ['list['+i+'].flag']: flag
        })
      }
      
      }
     })
  },
  onHide: function(){

  },
  onUnload: function(){

  },
  onPullDownRefresh: function(){

  },
  onReachBottom: function(){

  },
  onShareAppMessage: function(){

  },
  onPageScroll: function(){

  },
  //item(index,pagePath,text)
  onTabItemTap:function(item){

  }
});