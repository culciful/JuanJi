//app.js
App({
  //onLaunch,onShow: options(path,query,scene,shareTicket,referrerInfo(appId,extraData))
  globalData: {
    userinfo:null,
  },

  onLaunch: function(options){
    if(this.globalData.userinfo){
      wx.switchTab({
        url: 'page/index/index'
      })  
    }

  },
  onShow: function(options){

  },
  onHide: function(){

  },
  onError: function(msg){

  },
  //options(path,query,isEntryPage)
  onPageNotFound: function(options){

  },

});