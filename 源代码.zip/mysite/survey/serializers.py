from django.contrib.auth.models import User

from rest_framework import serializers

from .models import Survey, Question, Choice
from .models import QUESTION_TYPE_CHOICES, ANSWER, SINGLE, MULTI
from .models import SurveyResult, Answer, TextAnswer, ChoiceAnswer

import datetime

"""
可能是DRF的BUG

在序列化器中根据外键关系嵌套序列化时，在被引用方新建字段指向引用方，
字段名有特殊要求。

目前发现，将关系命名为relation_1，然后在被引用方序列化器新建字段relation_1
可以正常运作

Serializer和ModelSerializer均如此
"""
class ChoiceSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    c_body = serializers.CharField(max_length=255)

class QuestionSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    q_body = serializers.CharField()
    q_type = serializers.IntegerField()
    question = ChoiceSerializer(many=True)

class SurveyWithQuestion(serializers.ModelSerializer):
    #survey = QuestionSerializer(many=True, read_only=True)
    #参照https://stackoverflow.com/questions/48247490/django-rest-framework-nested-serializer-order/48249910
    #对输出结果排序
    survey = serializers.SerializerMethodField()
    
    class Meta:
        model = Survey
        fields = ('s_title', 's_intro', 's_create_time', 's_stop_time', 's_owner','survey')
    def get_survey(self, instance):
        qs = instance.survey.all().order_by('id')
        return QuestionSerializer(qs, many=True).data

class SurveySerializer(serializers.ModelSerializer):
    class Meta:
        model = Survey
        fields = ('id', 's_title','s_intro', 's_create_time', 's_stop_time', 's_owner')
    #    read_only_fields = ['id']

class SurveyCreateSerializer(serializers.ModelSerializer):
    
    #s_owner由save函数传入，所以不做校验
    def validate_s_owner(self, value):
        return value
    
    class Meta:
        model = Survey
        fields = ('id', 's_title', 's_intro', 's_create_time', 's_stop_time', 's_owner')
        read_only_fields = ['id', 's_create_time']

class ChoiceCreate(serializers.Serializer):
    c_body = serializers.CharField(max_length=255)

class QuestionCreate(serializers.Serializer):
    q_body = serializers.CharField()
    q_type = serializers.IntegerField()
    survey = serializers.PrimaryKeyRelatedField(queryset=Survey.objects.all())
    question = ChoiceCreate(many=True)

    def create(self, validated_data):
        #create a new Question to a Survey
        #try:
        #    refered_survey = Survey.objects.get(id=validated_data['survey'])
        #except Survey.DoesNotExist:
        #    return None 

        #validated_data['survey'] is a Survey Object
        q = Question.objects.create(q_body = validated_data['q_body'],
                q_type = validated_data['q_type'],\
                survey = validated_data['survey'])
#survey = refered_survey)

        for item in validated_data['question']:
            choice = Choice(c_body=item['c_body'], question=q);
            choice.save()

        return q

class SurveyResultSerializer(serializers.Serializer):
    answers = serializers.JSONField()

    def validate_answers(self, value):
        #print("answers validator: " + str(value))
        return value

    def create(self, validated_data):
        # return validated_data
        # validated_data确实是一个字典，但是它外面有其他方法，\
        # 导致不能向字典一样使用

        # print(validated_data['test_field'])
        # serializer.save()传入的参数，确实会出现在validated_data中

        #print(type(self.initial_data))
        # 字典，不能直接使用
        #answers = self.initial_data['answers']
        #'list' object has no attribute 'answers'
        pk = validated_data['survey']
        try:
            s = Survey.objects.get(id=pk)
        except Survey.DoesNotExist:
            return None
        tz = datetime.timezone(datetime.timedelta(hours=8))
        utc = datetime.datetime.utcnow()
        local = utc.replace(tzinfo=tz)

        sr = SurveyResult(sr_create_time=local, survey = s)
        for key,value in self.initial_data.items():
            if key == "answers":
                for i in value:
                    print(i)
                    if i.get('answer_choices'):
                        for j in i['answer_choices']:
                            print(j)
                    elif i.get('answer_text'):
                        print(i['answer_text'])

        return sr

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'password')
        read_only_fields = ['id']
        write_only_fields = ['password']

    def create(self, validated_data):
        user = User.objects.create(
            username = validated_data['username']
        )
        user.set_password(validated_data['password'])
        user.save()

        return user
    def update(self, instance, validated_data):
        if 'password' in validated_data:
            passwd = validated_data['password']
            instance.set_password(passwd)
            instance.save()

            return instance
