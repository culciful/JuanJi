from django.contrib import admin

from .models import Survey,Question,Choice,SurveyResult
from .models import Answer,TextAnswer,ChoiceAnswer

admin.site.register(Survey)
admin.site.register(Question)
admin.site.register(Choice)
admin.site.register(SurveyResult)
admin.site.register(Answer)
admin.site.register(TextAnswer)
admin.site.register(ChoiceAnswer)
