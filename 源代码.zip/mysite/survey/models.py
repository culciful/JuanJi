from django.db import models
from django.conf import settings

ANSWER = 0
SINGLE = 1
MULTI  = 2

QUESTION_TYPE_CHOICES = (
    (ANSWER, "text answer"),
    (SINGLE, "choice"),
    (MULTI, "choices"),
)


class Survey(models.Model):
    s_title = models.CharField(max_length=255)
    s_intro = models.TextField(blank=True)
    s_create_time = models.DateTimeField('date created', auto_now_add=True)
    s_stop_time = models.DateTimeField('date stoped')
    s_owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    def __str__(self):
        return self.s_title
"""
class Article(models.Model):
    headline = models.CharField(max_length=255)
    article = models.TextField()
"""

class Question(models.Model):
    q_body = models.TextField()
    q_type = models.SmallIntegerField(
        choices=QUESTION_TYPE_CHOICES,
        default=0,
        )
    survey = models.ForeignKey(Survey, related_name='survey',on_delete=models.CASCADE)

    def __str__(self):
        return self.q_body

class Choice(models.Model):
    c_body = models.CharField(max_length=255)
    question = models.ForeignKey(Question, related_name='question',on_delete=models.CASCADE)

    def __str__(self):
        return self.c_body

class SurveyResult(models.Model):
    sr_create_time =  models.DateTimeField('date created', auto_now_add=True)
    survey = models.ForeignKey(Survey, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id)

class Answer(models.Model):
    question = models.ForeignKey(Question, related_name='answers', on_delete=models.CASCADE)
    surveyresult = models.ForeignKey(SurveyResult, on_delete=models.CASCADE)

    def __str__(self):
        return "Answer" + str(self.id)
    
class TextAnswer(models.Model):
    ta_body = models.TextField()
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE)

    def __str__(self):
        return "Answer" + str(self.ta_body)

class ChoiceAnswer(models.Model):
    choice = models.ForeignKey(Choice, on_delete=models.CASCADE)
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE)

    def __str__(self):
        return "answer" + str(self.choice)
