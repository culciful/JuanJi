from survey.models import Survey, SurveyResult, Answer, Question, Choice
from survey.models import TextAnswer, ChoiceAnswer

import datetime

def create_surveyresult(json):
    survey_id = json.get("survey")
    s = Survey.objects.get(id=survey_id)
    
    # create surveyresult
    tz = datetime.timezone(datetime.timedelta(hours=8))
    utc = datetime.datetime.utcnow()
    local = utc.replace(tzinfo=tz)

    sr = SurveyResult(sr_create_time=local, survey = s)
    sr.save()

    #create answers
    answers = json.get("answers")

    for answer in answers:
        question_id = answer.get("question_id")
        question = Question.objects.get(id=question_id)
        ans = Answer(question=question, surveyresult = sr)
        ans.save()

        choices = answer.get("answer_choices")
        text = answer.get("answer_text")

        if choices is not None:
            #print(choices)
            for choice in choices:
                choice_instance = Choice.objects.get(id=choice)
                ca = ChoiceAnswer(choice = choice_instance, answer=ans)
                ca.save()
        elif text is not None:
            #print(text)
            ta = TextAnswer(ta_body=text, answer=ans)
            ta.save()
        else:
            print("Not  choices or  text Answer")
            
