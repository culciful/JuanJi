from django.http import HttpResponse
from django.shortcuts import render
from django.db import transaction, IntegrityError
from django.core.exceptions import ObjectDoesNotExist

from rest_framework import status, permissions
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.response import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication, TokenAuthentication

from .models import Survey, Question, Choice, SurveyResult
from .models import Answer, ChoiceAnswer, TextAnswer

from .serializers import SurveySerializer, SurveyWithQuestion
from .serializers import QuestionSerializer, ChoiceSerializer
from .serializers import QuestionCreate, SurveyCreateSerializer
from .serializers import SurveyResultSerializer
from .serializers import UserSerializer

from  survey.homemade import create_surveyresult
import json

# /
def index(request):
    return render(request, 'home.html')

@authentication_classes([BasicAuthentication, TokenAuthentication])
@api_view(['GET', 'POST'])
def survey_list(request):
    """
    GET /api/survey_list/   登陆用户获取survey列表和数量(注意，API已更新)

    POST /api/survey_list/  创建一个新survey,id会被服务器忽略，返回201和Survey对象

    """
    user = request.user

    if request.method == "GET":
        surveys = Survey.objects.filter(s_owner=user.id)
        serializer = SurveySerializer(surveys, many=True)

        dic = {}
        dic['num'] = len(serializer.data)
        dic['surveys'] = serializer.data

        #return Response(serializer.data)
        return Response(dic)
    elif request.method == "POST":
        serializer = SurveyCreateSerializer(data=request.data)
        #serializer = SurveySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(s_owner=user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
@authentication_classes([BasicAuthentication, TokenAuthentication])
@permission_classes([permissions.IsAuthenticatedOrReadOnly])
@api_view(['GET', 'POST', 'DELETE'])
def survey_detail(request,pk):
    """
    GET /survey/pk/     获取survey的详情(包含问题和问题选项)

    DELETE /survey/pk/  删除某个survey,以及下面的所有信息
    """

    user = request.user

    try:
        survey = Survey.objects.get(pk = pk)
        #survey = Survey.objects.filter(s_owner=user).get(pk=pk)
    except Survey.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = SurveyWithQuestion(survey)
        return Response(serializer.data)
#    elif request.method == 'POST':
#        serializer = QuestionSerializer(data=request.data)
#        if serializer.is_valid():
#            serializer.save(survey_id=survey.id)
#            return Response(serializer.data, status=status.HTTP_201_CREATED)
#        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #return HttpResponse(request.data)
    elif request.method == 'DELETE':
        if survey.s_owner == user:
            survey.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        else:
            return Response(status=status.HTTP_404_NOT_FOUND)

@authentication_classes([BasicAuthentication, TokenAuthentication])
@api_view(["POST"])
def question(request):
    """
    POST /api/question/     向指定servey添加question,并为question添加choices
    
    {   
	"q_body": "问题内容",
	"q_type": 1,            // 0,问答;1,单选;2，多选
	"survey": survey_id,    //目标Survey的id
	"question": [
		{
			"c_body": "选项1"
		},
		{
			"c_body": "选项2"
		},
                .....
	    ]   
    }

    """

    user = request.user

    if request.method == "POST":
        serializer = QuestionCreate(data=request.data)
        if serializer.is_valid():
            if serializer.validated_data['survey'].s_owner == user:
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(status=status.HTTP_404_NOT_FOUND)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #return Response(serializer.data, status=status.HTTP_400_BAD_REQUEST)
    elif request.method == "GET":
        pass
        
@api_view(["POST"])
@permission_classes([permissions.AllowAny])
def survey_result(request, pk):
    """
    <pre> 
    POST /api/survey_result/survey_id/      向编号为survey_id的问卷提交答案

    {
        "answers": [
            {
                "question_id": 9,       #问卷中问题的编号
                "answer_choices": [     #对于单选题的格式
                    6
                ]
            },
            {
                "question_id": 12,
                "answer_choices": [     #多选题的格式
                    14,
                    13,
                    12
                ]
            },
            {
                "question_id": 13,
                "answer_text": "没有意见，都挺好"   #问答题的格式(字段不一样!)
            }
        ]
    }
    </pre>

    """
    if request.method == "POST":
        json = request.data
        json['survey'] = pk
        
        try:
            with transaction.atomic():
                create_surveyresult(json)
        except IntegrityError:
            print("IntegrityError")
            return Response(status=status.HTTP_400_BAD_REQUEST)

        return Response(request.data)


        #serializer = SurveyResultSerializer(data=request.data)
        #if serializer.is_valid():
        #    serializer.save(survey =pk)
        #    return Response(serializer.data, status=status.HTTP_201_CREATED)
        #return Response(status=status.HTTP_400_BAD_REQUEST)

@permission_classes([permissions.IsAuthenticated])
@authentication_classes([BasicAuthentication, TokenAuthentication])
@api_view(["GET"])
def question_answer(request, pk):
    """
    <pre>
    返回答案的数量和包含答案的列表

    答案格式:

    对于选择题(单选、多选)
    {
        "id": 选项编号,
        "c_body": 选项内容
    }

    对于问答题
    {
        "ta_body": 回答的内容
    }
    </pre>
    """

    user = request.user
    if user.id == None:
        text = {"detail":"Authentication credentials were not provided."}
        return Response(text, status=status.HTTP_401_UNAUTHORIZED)

    if request.method == "GET":

    #    try:
    #        q = Question.objects.get(id=pk)
    #    except Question.DoesNotExist:
    #        return Response(status=status.HTTP_400_BAD_REQUEST)
        q = None
        qs = Question.objects.raw("select sq.* from survey_question sq, \
            survey_survey  ss where sq.survey_id = ss.id and \
                ss.s_owner_id = %s", [str(user.id)])

        for i in qs:
            if i.id == pk:
                q = i
        if q is None:
            return Response(status=status.HTTP_404_NOT_FOUND)

        result = {}
        result['num'] = 0
        result['answers'] = []
        
        if q.q_type == 0:
            tas = TextAnswer.objects.raw("select sta.* from survey_textanswer \
                    sta, survey_answer sa \
                    where sta.answer_id = sa.id and sa.question_id = %s",\
                        [str(pk),])
            for i in tas:
                d = {}
                d['ta_body'] = i.ta_body
                result['num'] += 1
                result['answers'].append(d)
        else:
            tas = ChoiceAnswer.objects.raw("select sca.* from \
                survey_choiceanswer sca, survey_answer sa \
                where sca.answer_id = sa.id and sa.question_id = %s",\
                    [str(pk),])

            for i in tas:
                d = {}
                #c = Choice.objects.get(id=i.answer_id)  问题所在
                c = Choice.objects.get(id=i.choice_id)
                d['id'] = c.id
                d['c_body'] = c.c_body

                result['num'] += 1
                result['answers'].append(d)

        return Response(result)

@api_view(["POST"])
@permission_classes([permissions.AllowAny])
def register(request):
    """
    <pre>
    POST /api/register/

    {
        "username": "xxx",
        "password": "yyy"
    }
    
    </pre>
    创建一个新用户，此API完全开放
    """
    serializer = UserSerializer(data=request.data)
    #serializer = SurveySerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def reset_password(request):
    """
    <pre>
    登陆用户重置密码
    POST /api/reset_password/
    {
        "username": "xxx",
        "password": "yyy"
    }
    </pre>
    """
    user = request.user
    serializer = UserSerializer(user, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

