from django.urls import path
import rest_framework.authtoken.views as tokenviews
from . import views

urlpatterns = [
    path('reset_password/', views.reset_password),
    path('register/', views.register),
    path('get_token/', tokenviews.obtain_auth_token),
    path('question/<int:pk>/', views.question_answer),
    path('survey_result/<int:pk>/', views.survey_result),
    path('question/', views.question),
    path('survey/<int:pk>/', views.survey_detail),
    path('survey_list/', views.survey_list),
    path('', views.index, name='index'),
]
